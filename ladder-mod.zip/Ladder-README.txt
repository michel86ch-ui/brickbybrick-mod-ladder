Ladder for Brick by Brick
https://github.com/michel86ch-ui/brickbybrick-mod-ladder

INSTALL
Unzip everything into the game folder, so that winhttp.dll sits next to BrickByBrick.exe
(Steam: right-click the game > Manage > Browse local files). BepInEx already installed
(e.g. with Extra Buildings)? Just overwrite, the files are the same.

HOW TO USE
L at the wall under the crosshair (up to 24 m away, also one set back above a lower roof): set up
the ladder, up to 24 m long (L at another wall moves it). L at the ladder: take it down.
Page Up / Page Down: 0.5 m longer / shorter.
Walk into the ladder facing the wall to climb; jump lets go. At the top you step off when
there is room. Settings: BepInEx\config\michel.brickbybrick.ladder.cfg (created at the first game start).
Note: a world in which you set up a ladder no longer counts for the Steam leaderboard.

UNINSTALL
Delete the folder BepInEx\plugins\Ladder.

Includes BepInEx 5.4.23.5, unmodified (MIT license: BepInEx\LICENSE-BepInEx.txt).
Unofficial fan mod, not made by the game's developers.
